-- 1. DATABASE SETUP
CREATE DATABASE IF NOT EXISTS ekspor_impor;
USE ekspor_impor;

-- 2. CREATE TABLES (Optimized)
SET FOREIGN_KEY_CHECKS = 0;

-- Tabel Users (Security Hardening)
CREATE TABLE IF NOT EXISTS Users (
    ID INT PRIMARY KEY AUTO_INCREMENT,
    Username VARCHAR(50) UNIQUE NOT NULL,
    Password VARCHAR(255) NOT NULL, -- Menyimpan Bcrypt Hash
    Role ENUM('Masyarakat', 'Staff', 'Pemerintah', 'Admin') NOT NULL,
    NamaLengkap VARCHAR(100)
);

CREATE TABLE IF NOT EXISTS SuratIzin (
    ID INT PRIMARY KEY,
    Jenis VARCHAR(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS Transportasi (
    ID VARCHAR(20) PRIMARY KEY,
    Jenis VARCHAR(50) NOT NULL,
    Kapasitas INT NOT NULL,
    WaktuPengiriman INT NOT NULL
);

CREATE TABLE IF NOT EXISTS PetugasIzin (
    IDPetugas INT AUTO_INCREMENT PRIMARY KEY,
    NamaPetugas VARCHAR(100) NOT NULL,
    Jabatan VARCHAR(50) NOT NULL,
    ParentID INT NULL, -- Untuk struktur hirarki/tree
    FOREIGN KEY (ParentID) REFERENCES PetugasIzin(IDPetugas)
);

CREATE TABLE IF NOT EXISTS Barang (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    Nama VARCHAR(100) NOT NULL,
    Jenis VARCHAR(50),
    Harga INT,
    Pajak DOUBLE,
    BeratBarang DOUBLE,
    NegaraAsal VARCHAR(100),
    NegaraTujuan VARCHAR(100),
    SuratIzinID INT,
    TransportasiID VARCHAR(20),
    FOREIGN KEY (SuratIzinID) REFERENCES SuratIzin(ID),
    FOREIGN KEY (TransportasiID) REFERENCES Transportasi(ID)
);

CREATE TABLE IF NOT EXISTS PetugasBarang (
    PetugasID INT,
    BarangID INT,
    PRIMARY KEY (PetugasID, BarangID),
    FOREIGN KEY (PetugasID) REFERENCES PetugasIzin(IDPetugas),
    FOREIGN KEY (BarangID) REFERENCES Barang(ID)
);

SET FOREIGN_KEY_CHECKS = 1;

-- 3. INDEXING (PENTING untuk 500.000+ data agar tidak LAG)
CREATE INDEX idx_barang_nama ON Barang(Nama);
CREATE INDEX idx_barang_jenis ON Barang(Jenis);
CREATE INDEX idx_barang_asal ON Barang(NegaraAsal);
CREATE INDEX idx_barang_tujuan ON Barang(NegaraTujuan);
CREATE INDEX idx_petugas_parent ON PetugasIzin(ParentID);

-- 4. CLEAN DATA
TRUNCATE TABLE PetugasBarang;
TRUNCATE TABLE Barang;
TRUNCATE TABLE PetugasIzin;
TRUNCATE TABLE Transportasi;
TRUNCATE TABLE SuratIzin;
TRUNCATE TABLE Users;

-- 5. INITIAL USER SEED (Password Default setelah Migrate)
-- Catatan: Password di bawah adalah hash untuk 'admin123', 'pem123', dll.
INSERT INTO Users (Username, Password, Role, NamaLengkap) VALUES 
('admin', '$2a$12$Kk.zM2fS/vU.yZJbQ2EaHeuD6yHwI2pU6ZqjJQzqJQzqJQzqJQzq', 'Admin', 'Super Admin'),
('pemerintah', '$2a$12$R.yZJbQ2EaHeuD6yHwI2pU6ZqjJQzqJQzqJQzqJQzqJQzqJQzq', 'Pemerintah', 'Pejabat Pusat');

-- 6. STORED PROCEDURE SEED (High Performance)
DELIMITER $$

CREATE PROCEDURE seed_all_data()
BEGIN
    DECLARE i INT DEFAULT 1;
    DECLARE max_data INT DEFAULT 500000;
    DECLARE last_petugas_id INT;
    
    -- Optimize: Transaksi agar super cepat
    SET AUTOCOMMIT = 0;
    
    WHILE i <= max_data DO
        -- Surat Izin
        INSERT IGNORE INTO SuratIzin (ID, Jenis) VALUES (i, IF(i % 2 = 0, 'Impor', 'Ekspor'));
        
        -- Transportasi
        INSERT IGNORE INTO Transportasi (ID, Jenis, Kapasitas, WaktuPengiriman) 
        VALUES (CONCAT('TR', i), 'Laut', 10000, 72);
        
        -- Petugas (Hirarki: Setiap 10 petugas punya 1 supervisor)
        INSERT INTO PetugasIzin (NamaPetugas, Jabatan, ParentID)
        VALUES (
            CONCAT('Petugas ', i), 
            IF(i % 10 = 0, 'Supervisor', 'Staff'),
            IF(i % 10 = 0, NULL, i - (i % 10))
        );
        SET last_petugas_id = LAST_INSERT_ID();
        
        -- Barang
        INSERT INTO Barang (Nama, Jenis, Harga, Pajak, BeratBarang, NegaraAsal, NegaraTujuan, SuratIzinID, TransportasiID)
        VALUES (
            CONCAT('Barang ', i),
            CASE (i % 4) WHEN 0 THEN 'Elektronik' WHEN 1 THEN 'Tekstil' WHEN 2 THEN 'Mesin' ELSE 'Furniture' END,
            FLOOR(100000 + RAND() * 1000000),
            0.1,
            ROUND(1 + RAND() * 50, 2),
            'China',
            'Indonesia',
            i,
            CONCAT('TR', i)
        );
        
        -- Relasi
        INSERT INTO PetugasBarang (PetugasID, BarangID) VALUES (last_petugas_id, i);
        
        -- Commit per 10.000 data agar memory tidak bengkak
        IF i % 10000 = 0 THEN
            COMMIT;
        END IF;
        
        SET i = i + 1;
    END WHILE;
    
    COMMIT;
    SET AUTOCOMMIT = 1;
END$$

DELIMITER ;

-- 7. JALANKAN SEED
CALL seed_all_data();