//go:build ignore

package main

import (
	"database/sql"
	"fmt"
	"log"
	"os"
	"strings"

	_ "github.com/go-sql-driver/mysql"
)

func main() {
	// 1. Connect WITHOUT database name to ensure it exists
	dsnRoot := "root:@tcp(127.0.0.1:3306)/"
	db, err := sql.Open("mysql", dsnRoot)
	if err != nil {
		log.Fatal("Error connecting to MySQL: ", err)
	}
	defer db.Close()

	_, err = db.Exec("CREATE DATABASE IF NOT EXISTS ekspor_impor")
	if err != nil {
		log.Fatal("Failed to create database: ", err)
	}
	fmt.Println("Database 'ekspor_impor' checked/created.")

	// 2. Connect WITH database name
	dsnDb := "root:@tcp(127.0.0.1:3306)/ekspor_impor"
	dbWithName, err := sql.Open("mysql", dsnDb)
	if err != nil {
		log.Fatal("Error connecting to ekspor_impor_db: ", err)
	}
	defer dbWithName.Close()

	// 3. Read setup.sql
	content, err := os.ReadFile("setup.sql")
	if err != nil {
		log.Fatal("Failed to read setup.sql: ", err)
	}

	// 4. Split and Execute (Simple split by semicolon)
	// Note: DELIMITER commands are for MySQL Client, not standard SQL via Driver.
	// We will filter those out or stop.
	queries := strings.Split(string(content), ";")

	for _, query := range queries {
		query = strings.TrimSpace(query)
		if query == "" {
			continue
		}
		// Skip client-side commands that might cause errors
		if strings.HasPrefix(strings.ToUpper(query), "DELIMITER") ||
			strings.HasPrefix(strings.ToUpper(query), "USE") {
			continue
		}

		// Warning: The Stored Procedure in setup.sql uses non-standard delimiters which might break this simple split.
		// For safety, let's just create tables. If we hit the procedure definition (CREATE PROCEDURE),
		// it might fail or look like partial query.
		// Simple fix: We strictly run CREATE TABLE and INSERTs if we detect them.
		if strings.HasPrefix(strings.ToUpper(query), "CREATE TABLE") ||
			strings.HasPrefix(strings.ToUpper(query), "INSERT") {
			_, err := dbWithName.Exec(query)
			if err != nil {
				log.Printf("Warning: Failed to execute query: %s\nError: %v", query, err)
			} else {
				fmt.Println("Executed query successfully.")
			}
		}
	}

	// 5. Seed Minimal Dummy Data (Directly here to ensure API works immediately)
	fmt.Println("Seeding initial data if empty...")

	// Create USERS Table
	_, err = dbWithName.Exec(`
		CREATE TABLE IF NOT EXISTS Users (
			ID INT PRIMARY KEY AUTO_INCREMENT,
			Username VARCHAR(50) UNIQUE NOT NULL,
			Password VARCHAR(255) NOT NULL,
			Role ENUM('Masyarakat', 'Staff', 'Pemerintah', 'Admin') NOT NULL,
			NamaLengkap VARCHAR(100)
		);
	`)
	if err != nil {
		log.Printf("Warning: Failed to create Users table: %v", err)
	}

	// Seed Users
	dbWithName.Exec(`
		INSERT IGNORE INTO Users (Username, Password, Role, NamaLengkap) VALUES 
		('admin', 'admin123', 'Admin', 'Administrator'),
		('pemerintah', 'pem123', 'Pemerintah', 'Pejabat Pemerintah'),
		('staff', 'staff123', 'Staff', 'Petugas Gudang'),
		('user', 'user123', 'Masyarakat', 'Warga Sipil');
	`)

	seedQuery := `
		INSERT IGNORE INTO SuratIzin (ID, Jenis) VALUES (1, 'Impor'), (2, 'Ekspor');
		INSERT IGNORE INTO Transportasi (ID, Jenis, Kapasitas, WaktuPengiriman) VALUES 
			('TR1', 'Darat', 5000, 24),
			('TR2', 'Udara', 1000, 5);
		INSERT IGNORE INTO Barang (Nama, Jenis, Harga, Pajak, BeratBarang, SuratIzinID, TransportasiID) VALUES 
			('Kopi Luwak', 'Makanan', 150000, 0.1, 1.5, 1, 'TR1'),
			('Laptop Asus', 'Elektronik', 12000000, 0.2, 2.5, 1, 'TR2');
	`
	// Split seed query too
	seedQueries := strings.Split(seedQuery, ";")
	for _, q := range seedQueries {
		q = strings.TrimSpace(q)
		if q != "" {
			dbWithName.Exec(q)
		}
	}

	fmt.Println("SUCCESS: Database Setup & Seeding Complete!")
}
