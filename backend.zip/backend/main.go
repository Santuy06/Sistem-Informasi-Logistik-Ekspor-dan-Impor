package main

import (
	"database/sql"
	"fmt"
	"log"
	"net/http"
	"os"
	"strconv"
	"sync"
	"time"

	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"
	_ "github.com/go-sql-driver/mysql"
	"github.com/golang-jwt/jwt/v5"
	"github.com/joho/godotenv"
	"golang.org/x/crypto/bcrypt"
)

// -- Structs (Adapted from User Code) --

// -- Structs (Matched to SQL Schema) --

type User struct {
	ID          int    `json:"id"`
	Username    string `json:"username"`
	Password    string `json:"password"`
	Role        string `json:"role"`
	NamaLengkap string `json:"nama_lengkap"`
}

type LoginRequest struct {
	Username string `json:"username"`
	Password string `json:"password"`
}

type Petugas struct {
	ID          int       `json:"id"`
	NamaPetugas string    `json:"nama_petugas"`
	Jabatan     string    `json:"jabatan"`
	ParentID    *int      `json:"parent_id,omitempty"` // NULL jika root
	Children    []Petugas `json:"children,omitempty"`  // Untuk struktur tree
}

type SuratIzin struct {
	ID    int    `json:"id"`
	Jenis string `json:"jenis"`
}

type Transportasi struct {
	ID              string  `json:"id"`
	Jenis           string  `json:"jenis"`
	Kapasitas       float64 `json:"kapasitas"` // Replaces BiayaPerKM? From SQL
	WaktuPengiriman int     `json:"waktu_pengiriman"`
}

type Barang struct {
	ID             int     `json:"id"`
	Nama           string  `json:"nama"`
	Jenis          string  `json:"jenis"`
	Harga          int     `json:"harga"`
	Pajak          float64 `json:"pajak"`
	BeratBarang    float64 `json:"berat_barang"`
	SuratIzinID    int     `json:"surat_izin_id"`
	TransportasiID string  `json:"transportasi_id"`
	NegaraAsal     string  `json:"negara_asal"`
	NegaraTujuan   string  `json:"negara_tujuan"`
}

var db *sql.DB

// MAX_PETUGAS_RECORDS - Limiter untuk mencegah load data berlebihan
// Default: 10000 records, bisa diubah via environment variable MAX_PETUGAS_RECORDS
var MAX_PETUGAS_RECORDS int

// JWT_SECRET - Secret key untuk JWT token signing
var JWT_SECRET []byte

// -- Security Helper Functions --

// hashPassword - Hash password menggunakan bcrypt dengan cost 12
func hashPassword(password string) (string, error) {
	hash, err := bcrypt.GenerateFromPassword([]byte(password), 12)
	if err != nil {
		return "", err
	}
	return string(hash), nil
}

// comparePassword - Compare plain password dengan hashed password
func comparePassword(hashedPassword, password string) bool {
	err := bcrypt.CompareHashAndPassword([]byte(hashedPassword), []byte(password))
	return err == nil
}

// JWTClaims - Custom claims untuk JWT token
type JWTClaims struct {
	UserID   int    `json:"user_id"`
	Username string `json:"username"`
	Role     string `json:"role"`
	jwt.RegisteredClaims
}

// generateJWT - Generate JWT token dengan expiry 24 jam
func generateJWT(userID int, username, role string) (string, error) {
	claims := JWTClaims{
		UserID:   userID,
		Username: username,
		Role:     role,
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(time.Now().Add(24 * time.Hour)),
			IssuedAt:  jwt.NewNumericDate(time.Now()),
			Issuer:    "ekspor-impor-system",
		},
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	return token.SignedString(JWT_SECRET)
}

// validateJWT - Validate JWT token dan return claims
func validateJWT(tokenString string) (*JWTClaims, error) {
	token, err := jwt.ParseWithClaims(tokenString, &JWTClaims{}, func(token *jwt.Token) (interface{}, error) {
		if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, fmt.Errorf("unexpected signing method: %v", token.Header["alg"])
		}
		return JWT_SECRET, nil
	})

	if err != nil {
		return nil, err
	}

	if claims, ok := token.Claims.(*JWTClaims); ok && token.Valid {
		return claims, nil
	}

	return nil, fmt.Errorf("invalid token")
}

// authMiddleware - Middleware untuk validasi JWT token
func authMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		authHeader := c.GetHeader("Authorization")
		if authHeader == "" {
			c.JSON(http.StatusUnauthorized, gin.H{"error": "Authorization header required"})
			c.Abort()
			return
		}

		// Format: "Bearer <token>"
		tokenString := authHeader
		if len(authHeader) > 7 && authHeader[:7] == "Bearer " {
			tokenString = authHeader[7:]
		}

		claims, err := validateJWT(tokenString)
		if err != nil {
			c.JSON(http.StatusUnauthorized, gin.H{"error": "Invalid or expired token"})
			c.Abort()
			return
		}

		// Set user info to context
		c.Set("user_id", claims.UserID)
		c.Set("username", claims.Username)
		c.Set("role", claims.Role)
		c.Next()
	}
}

// securityHeaders - Middleware untuk menambahkan security headers
func securityHeaders() gin.HandlerFunc {
	return func(c *gin.Context) {
		// Prevent clickjacking
		c.Header("X-Frame-Options", "DENY")

		// Prevent MIME sniffing
		c.Header("X-Content-Type-Options", "nosniff")

		// Enable XSS protection
		c.Header("X-XSS-Protection", "1; mode=block")

		// Content Security Policy - basic policy
		c.Header("Content-Security-Policy", "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'")

		// Referrer Policy
		c.Header("Referrer-Policy", "strict-origin-when-cross-origin")

		// HSTS - Force HTTPS (commented out untuk development)
		// Uncomment this di production dengan HTTPS
		// c.Header("Strict-Transport-Security", "max-age=31536000; includeSubDomains")

		c.Next()
	}
}

// Simple in-memory rate limiter
type rateLimitEntry struct {
	count     int
	resetTime time.Time
}

var rateLimitMap = make(map[string]*rateLimitEntry)
var rateLimitMutex = &sync.Mutex{}

// loginRateLimiter - Rate limit login attempts (5 per minute per IP)
func loginRateLimiter() gin.HandlerFunc {
	return func(c *gin.Context) {
		clientIP := c.ClientIP()

		rateLimitMutex.Lock()
		defer rateLimitMutex.Unlock()

		now := time.Now()
		entry, exists := rateLimitMap[clientIP]

		// Reset if time window passed
		if !exists || now.After(entry.resetTime) {
			rateLimitMap[clientIP] = &rateLimitEntry{
				count:     1,
				resetTime: now.Add(1 * time.Minute),
			}
			c.Next()
			return
		}

		// Check limit
		if entry.count >= 5 {
			c.JSON(http.StatusTooManyRequests, gin.H{
				"error": "Too many login attempts. Please try again later.",
			})
			c.Abort()
			return
		}

		// Increment counter
		entry.count++
		c.Next()
	}
}

func main() {
	var err error

	// Load .env file (optional - won't fail if file doesn't exist)
	godotenv.Load()

	// Initialize JWT_SECRET from environment variable
	jwtSecret := os.Getenv("JWT_SECRET")
	if jwtSecret == "" {
		// Generate a warning but use default (NOT RECOMMENDED FOR PRODUCTION)
		jwtSecret = "default-secret-key-please-change-in-production-min-32-chars"
		log.Println("WARNING: JWT_SECRET not set in environment. Using default (INSECURE)")
	}
	JWT_SECRET = []byte(jwtSecret)

	// Database Connection - prefer environment variable `DATABASE_URL`
	dsn := os.Getenv("DATABASE_URL")
	if dsn == "" {
		// fallback to local default for development
		dsn = "root:@tcp(127.0.0.1:3306)/ekspor_impor"
	}
	db, err = sql.Open("mysql", dsn)
	if err != nil {
		log.Fatal("Error connecting to database: ", err)
	}
	defer db.Close()

	// Initialize MAX_PETUGAS_RECORDS from env or use default
	maxPetugasEnv := os.Getenv("MAX_PETUGAS_RECORDS")
	if maxPetugasEnv != "" {
		MAX_PETUGAS_RECORDS, err = strconv.Atoi(maxPetugasEnv)
		if err != nil || MAX_PETUGAS_RECORDS < 1 {
			MAX_PETUGAS_RECORDS = 10000 // Fallback to default
		}
	} else {
		MAX_PETUGAS_RECORDS = 10000 // Default 10k records
	}
	log.Printf("MAX_PETUGAS_RECORDS set to: %d", MAX_PETUGAS_RECORDS)

	// Check connection
	if err := db.Ping(); err != nil {
		log.Println("Warning: Could not connect to MySQL. Ensure it is running.")
	} else {
		log.Println("Connected to MySQL successfully.")
	}

	r := gin.Default()

	// Security Headers Middleware
	r.Use(securityHeaders())

	// CORS Setup
	r.Use(cors.New(cors.Config{
		AllowOrigins:     []string{"http://localhost:5173"},
		AllowMethods:     []string{"GET", "POST", "PUT", "DELETE"},
		AllowHeaders:     []string{"Origin", "Content-Type", "Authorization"},
		AllowCredentials: true,
	}))

	// Routes
	r.GET("/", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{
			"status":  "running",
			"message": "Backend Go Sistem Ekspor Impor Ready!",
		})
	})

	api := r.Group("/api")
	{
		api.POST("/login", loginRateLimiter(), login)

		// Barang (Existing)
		api.GET("/barang", getBarang)                             // Public read
		api.POST("/barang", authMiddleware(), createBarang)       // Protected
		api.PUT("/barang/:id", authMiddleware(), updateBarang)    // Protected
		api.DELETE("/barang/:id", authMiddleware(), deleteBarang) // Protected
		api.GET("/barang/stats", getBarangStats)                  // Public read
		api.GET("/cari", cariBarang)                              // Public read
		api.POST("/estimasi", hitungEstimasi)                     // Public calculator

		// Master Data: Transportasi
		api.GET("/transportasi", getTransportasi)                             // Public read
		api.POST("/transportasi", authMiddleware(), createTransportasi)       // Protected
		api.PUT("/transportasi/:id", authMiddleware(), updateTransportasi)    // Protected
		api.DELETE("/transportasi/:id", authMiddleware(), deleteTransportasi) // Protected

		// Master Data: Surat Izin (ITERATIF)
		api.GET("/surat-izin", getSuratIzin)                             // Public read
		api.POST("/surat-izin", authMiddleware(), createSuratIzin)       // Protected
		api.PUT("/surat-izin/:id", authMiddleware(), updateSuratIzin)    // Protected
		api.DELETE("/surat-izin/:id", authMiddleware(), deleteSuratIzin) // Protected

		// Master Data: Petugas (ITERATIF atau REKURSIF via query param ?method=)
		api.GET("/petugas", getPetugas)                             // Public read - ?method=iteratif (default) atau ?method=rekursif
		api.POST("/petugas", authMiddleware(), createPetugas)       // Protected
		api.PUT("/petugas/:id", authMiddleware(), updatePetugas)    // Protected
		api.DELETE("/petugas/:id", authMiddleware(), deletePetugas) // Protected

	}

	// Respect PORT env var for hosting platforms
	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}
	r.Run(":" + port)
}

// -- Handlers --

// getBarang
func getBarang(c *gin.Context) {
	pageStr := c.DefaultQuery("page", "1")
	pageSizeStr := c.DefaultQuery("pageSize", "10")

	page, _ := strconv.Atoi(pageStr)
	if page < 1 {
		page = 1
	}

	pageSize, _ := strconv.Atoi(pageSizeStr)
	if pageSize < 1 {
		pageSize = 10
	}
	if pageSize > 100 {
		pageSize = 100
	}

	offset := (page - 1) * pageSize

	// Get search filters from query params
	namaFilter := c.Query("name")
	jenisFilter := c.Query("type")
	asalFilter := c.Query("origin")
	tujuanFilter := c.Query("destination")

	// Build dynamic WHERE clause
	whereClause := "WHERE 1=1"
	var args []interface{}

	if namaFilter != "" {
		whereClause += " AND Nama LIKE ?"
		args = append(args, "%"+namaFilter+"%")
	}
	if jenisFilter != "" {
		whereClause += " AND Jenis LIKE ?"
		args = append(args, "%"+jenisFilter+"%")
	}
	if asalFilter != "" {
		whereClause += " AND NegaraAsal LIKE ?"
		args = append(args, "%"+asalFilter+"%")
	}
	if tujuanFilter != "" {
		whereClause += " AND NegaraTujuan LIKE ?"
		args = append(args, "%"+tujuanFilter+"%")
	}

	// Build query for matching data
	dataQuery := fmt.Sprintf(`SELECT ID, COALESCE(Nama, ''), COALESCE(Jenis, ''), Harga, Pajak, BeratBarang, SuratIzinID, TransportasiID, COALESCE(NegaraAsal, ''), COALESCE(NegaraTujuan, '') 
	          FROM Barang %s LIMIT ? OFFSET ?`, whereClause)

	// Build query for total count (same WHERE clause)
	countQuery := fmt.Sprintf("SELECT COUNT(*) FROM Barang %s", whereClause)

	// Get total count
	var total int
	err := db.QueryRow(countQuery, args...).Scan(&total)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to count data", "details": err.Error()})
		return
	}

	// Add pagination args for data query
	dataArgs := append(args, pageSize, offset)

	rows, err := db.Query(dataQuery, dataArgs...)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to fetch data from DB", "details": err.Error()})
		return
	}
	defer rows.Close()

	var results []Barang = []Barang{}
	for rows.Next() {
		var b Barang
		if err := rows.Scan(&b.ID, &b.Nama, &b.Jenis, &b.Harga, &b.Pajak, &b.BeratBarang, &b.SuratIzinID, &b.TransportasiID, &b.NegaraAsal, &b.NegaraTujuan); err != nil {
			log.Printf("Error scanning row: %v", err)
			continue
		}
		results = append(results, b)
	}

	c.JSON(http.StatusOK, gin.H{
		"data":  results,
		"total": total,
	})
}

// cariBarang
func cariBarang(c *gin.Context) {
	keyword := c.Query("q")
	// Updated to fetch all fields to match struct, or just subset
	query := `SELECT ID, Nama, Jenis, Harga, Pajak, BeratBarang, SuratIzinID, TransportasiID, NegaraAsal, NegaraTujuan 
	          FROM Barang WHERE Nama LIKE ?`
	rows, err := db.Query(query, "%"+keyword+"%")
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	defer rows.Close()

	var results []Barang
	for rows.Next() {
		var b Barang
		if err := rows.Scan(&b.ID, &b.Nama, &b.Jenis, &b.Harga, &b.Pajak, &b.BeratBarang, &b.SuratIzinID, &b.TransportasiID, &b.NegaraAsal, &b.NegaraTujuan); err != nil {
			continue
		}
		results = append(results, b)
	}
	c.JSON(http.StatusOK, results)
}

// -- Calculation Rules --
var CountryTaxes = map[string]float64{
	"Indonesia": 0.11,
	"China":     0.15,
	"Amerika":   0.20,
	"Jepang":    0.12,
	"Singapura": 0.07,
	"Vietnam":   0.10,
}

var ItemTypeMultipliers = map[string]float64{
	"Elektronik": 1.5,
	"Tekstil":    1.2,
	"Makanan":    1.0,
	"Otomotif":   2.0,
	"Obat":       0.8,
}

// hitungEstimasi
func hitungEstimasi(c *gin.Context) {
	var input struct {
		Activity    string `json:"activity"` // Impor / Ekspor
		Price       int    `json:"price"`
		Type        string `json:"type"`
		Origin      string `json:"origin"`
		Destination string `json:"destination"`
	}

	if err := c.BindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid input"})
		return
	}

	// Base Rates
	baseTaxRate := 0.10 // Default 10%
	if rate, ok := CountryTaxes[input.Origin]; ok {
		baseTaxRate = rate
	} else if rate, ok := CountryTaxes[input.Destination]; ok {
		baseTaxRate = rate
	}

	// Multiplier based on Item Type
	multiplier := 1.0
	if m, ok := ItemTypeMultipliers[input.Type]; ok {
		multiplier = m
	}

	// Logic: Impor usually higher than Ekspor
	activityMultiplier := 1.0
	if input.Activity == "Impor" {
		activityMultiplier = 1.2
	} else {
		activityMultiplier = 0.8
	}

	// Calculate Results
	appliedTaxRate := baseTaxRate * multiplier * activityMultiplier
	pajakNilai := float64(input.Price) * appliedTaxRate

	// Dummy Transport based on distance simulation (randomized distance)
	jarak := 100.0
	biayaTransport := jarak * 5000.0 * multiplier // Heavier/More complex items cost more to ship

	total := float64(input.Price) + pajakNilai + biayaTransport

	c.JSON(http.StatusOK, gin.H{
		"activity":        input.Activity,
		"harga_awal":      input.Price,
		"pajak_persen":    appliedTaxRate * 100,
		"pajak_nilai":     pajakNilai,
		"biaya_transport": biayaTransport,
		"total_biaya":     total,
		"info":            fmt.Sprintf("Dihitung berdasarkan kebijakan %s untuk jenis %s", input.Activity, input.Type),
	})
}

// -- Auth Handler --

func login(c *gin.Context) {
	var input LoginRequest
	if err := c.BindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid input"})
		return
	}

	// Input validation
	if len(input.Username) < 3 || len(input.Password) < 3 {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Username and password must be at least 3 characters"})
		return
	}

	var user User
	var hashedPassword string

	// Fetch user dengan hashed password
	err := db.QueryRow("SELECT ID, Username, Password, Role, NamaLengkap FROM Users WHERE Username = ?", input.Username).
		Scan(&user.ID, &user.Username, &hashedPassword, &user.Role, &user.NamaLengkap)

	if err != nil {
		if err == sql.ErrNoRows {
			c.JSON(http.StatusUnauthorized, gin.H{"error": "Invalid credentials"})
		} else {
			// Log error server-side, tapi jangan expose ke client
			log.Printf("Login database error: %v", err)
			c.JSON(http.StatusInternalServerError, gin.H{"error": "An internal error occurred"})
		}
		return
	}

	// Verify password menggunakan bcrypt
	if !comparePassword(hashedPassword, input.Password) {
		c.JSON(http.StatusUnauthorized, gin.H{"error": "Invalid credentials"})
		return
	}

	// Generate JWT token
	token, err := generateJWT(user.ID, user.Username, user.Role)
	if err != nil {
		log.Printf("JWT generation error: %v", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to generate token"})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"token":    token,
		"role":     user.Role,
		"username": user.Username,
	})
}

// -- Master Data Handlers: Transportasi --

func getTransportasi(c *gin.Context) {
	rows, err := db.Query("SELECT ID, Jenis, Kapasitas, WaktuPengiriman FROM Transportasi")
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	defer rows.Close()

	var results []Transportasi
	for rows.Next() {
		var t Transportasi
		if err := rows.Scan(&t.ID, &t.Jenis, &t.Kapasitas, &t.WaktuPengiriman); err != nil {
			continue
		}
		results = append(results, t)
	}
	c.JSON(http.StatusOK, results)
}

func createTransportasi(c *gin.Context) {
	var t Transportasi
	if err := c.BindJSON(&t); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	_, err := db.Exec("INSERT INTO Transportasi (ID, Jenis, Kapasitas, WaktuPengiriman) VALUES (?, ?, ?, ?)", t.ID, t.Jenis, t.Kapasitas, t.WaktuPengiriman)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "Transportasi created"})
}

func updateTransportasi(c *gin.Context) {
	id := c.Param("id")
	var t Transportasi
	if err := c.BindJSON(&t); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	_, err := db.Exec("UPDATE Transportasi SET Jenis=?, Kapasitas=?, WaktuPengiriman=? WHERE ID=?", t.Jenis, t.Kapasitas, t.WaktuPengiriman, id)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "Transportasi updated"})
}

func deleteTransportasi(c *gin.Context) {
	id := c.Param("id")
	_, err := db.Exec("DELETE FROM Transportasi WHERE ID=?", id)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "Transportasi deleted"})
}

// -- Master Data Handlers: SuratIzin --

func getSuratIzin(c *gin.Context) {
	rows, err := db.Query("SELECT ID, Jenis FROM SuratIzin")
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	defer rows.Close()
	var results []SuratIzin
	for rows.Next() {
		var s SuratIzin
		rows.Scan(&s.ID, &s.Jenis)
		results = append(results, s)
	}
	c.JSON(http.StatusOK, results)
}

func createSuratIzin(c *gin.Context) {
	var s SuratIzin
	if err := c.BindJSON(&s); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	_, err := db.Exec("INSERT INTO SuratIzin (ID, Jenis) VALUES (?, ?)", s.ID, s.Jenis)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "Surat Izin created"})
}

func updateSuratIzin(c *gin.Context) {
	id := c.Param("id")
	var s SuratIzin
	if err := c.BindJSON(&s); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	_, err := db.Exec("UPDATE SuratIzin SET Jenis=? WHERE ID=?", s.Jenis, id)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "Surat Izin updated"})
}

func deleteSuratIzin(c *gin.Context) {
	id := c.Param("id")
	_, err := db.Exec("DELETE FROM SuratIzin WHERE ID=?", id)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "Surat Izin deleted"})
}

// -- Master Data Handlers: PetugasIzin --

// getPetugas - Fetch dengan opsi Rekursif atau Iteratif
func getPetugas(c *gin.Context) {
	method := c.DefaultQuery("method", "iteratif")
	nama := c.Query("nama")
	jabatan := c.Query("jabatan")

	if method == "rekursif" {
		// Fetch Petugas dengan struktur hirarki (rekursif)
		maxDepthStr := c.DefaultQuery("maxDepth", "10")
		maxDepth, _ := strconv.Atoi(maxDepthStr)
		if maxDepth < 1 {
			maxDepth = 10
		}
		if maxDepth > 20 {
			maxDepth = 20
		}

		results := getPetugasHierarchy(nil, 0, maxDepth, nama, jabatan)
		c.JSON(http.StatusOK, gin.H{
			"data":     results,
			"method":   "rekursif",
			"maxDepth": maxDepth,
			"filters":  gin.H{"nama": nama, "jabatan": jabatan},
		})
	} else {
		// Fetch Petugas flat list (iteratif) dengan pagination
		pageStr := c.DefaultQuery("page", "1")
		pageSizeStr := c.DefaultQuery("pageSize", "50")

		page, _ := strconv.Atoi(pageStr)
		if page < 1 {
			page = 1
		}

		pageSize, _ := strconv.Atoi(pageSizeStr)
		if pageSize < 1 {
			pageSize = 50
		}
		if pageSize > MAX_PETUGAS_RECORDS {
			pageSize = MAX_PETUGAS_RECORDS
		}

		results, total := getAllPetugasList(page, pageSize, nama, jabatan)
		c.JSON(http.StatusOK, gin.H{
			"data":           results,
			"total":          total,
			"page":           page,
			"pageSize":       pageSize,
			"method":         "iteratif",
			"maxRecordLimit": MAX_PETUGAS_RECORDS,
			"filters":        gin.H{"nama": nama, "jabatan": jabatan},
		})
	}
}

// getAllPetugasList - ITERATIF: Ambil semua Petugas tanpa hirarki (dengan pagination dan server-side filtering)
func getAllPetugasList(page, pageSize int, nama, jabatan string) ([]Petugas, int) {
	// Base query parts
	whereClause := " WHERE 1=1"
	var args []interface{}

	if nama != "" {
		whereClause += " AND NamaPetugas LIKE ?"
		args = append(args, "%"+nama+"%")
	}
	if jabatan != "" {
		whereClause += " AND Jabatan LIKE ?"
		args = append(args, "%"+jabatan+"%")
	}

	// Get total count for this specific filter
	var count int
	err := db.QueryRow("SELECT COUNT(*) FROM PetugasIzin"+whereClause, args...).Scan(&count)
	if err != nil {
		log.Println("Error counting petugas with filters:", err)
		return []Petugas{}, 0
	}

	// Calculate offset
	offset := (page - 1) * pageSize

	// Final Query with LIMIT/OFFSET
	query := "SELECT IDPetugas, NamaPetugas, Jabatan, COALESCE(ParentID, NULL) FROM PetugasIzin" +
		whereClause + " LIMIT ? OFFSET ?"

	argsWithLimit := append(args, pageSize, offset)

	rows, err := db.Query(query, argsWithLimit...)
	if err != nil {
		log.Println("Error filtering petugas list:", err)
		return []Petugas{}, count
	}
	defer rows.Close()

	var results []Petugas
	for rows.Next() {
		var p Petugas
		var parentID sql.NullInt64
		if err := rows.Scan(&p.ID, &p.NamaPetugas, &p.Jabatan, &parentID); err != nil {
			log.Println("Error scanning filtered petugas:", err)
			continue
		}
		if parentID.Valid {
			pid := int(parentID.Int64)
			p.ParentID = &pid
		}
		results = append(results, p)
	}
	return results, count
}

// getPetugasHierarchy - REKURSIF: Ambil Petugas dengan struktur hirarki
func getPetugasHierarchy(parentID *int, currentDepth int, maxDepth int, nama, jabatan string) []Petugas {
	// BASE CASE 1: Stop jika sudah mencapai max depth
	if currentDepth >= maxDepth {
		return []Petugas{}
	}

	var query string
	var args []interface{}

	if parentID == nil {
		// Root level - apply filtering if provided
		query = "SELECT IDPetugas, NamaPetugas, Jabatan, COALESCE(ParentID, NULL) FROM PetugasIzin WHERE ParentID IS NULL"
		if nama != "" {
			query += " AND NamaPetugas LIKE ?"
			args = append(args, "%"+nama+"%")
		}
		if jabatan != "" {
			query += " AND Jabatan LIKE ?"
			args = append(args, "%"+jabatan+"%")
		}
	} else {
		// Children level - fetch normally based on ParentID
		query = "SELECT IDPetugas, NamaPetugas, Jabatan, COALESCE(ParentID, NULL) FROM PetugasIzin WHERE ParentID = ?"
		args = append(args, *parentID)
	}

	rows, err := db.Query(query, args...)
	if err != nil {
		log.Println("Error querying petugas hierarchy:", err)
		return []Petugas{}
	}
	defer rows.Close()

	var results []Petugas
	for rows.Next() { // ITERATIF untuk loop results
		var p Petugas
		var pid sql.NullInt64
		if err := rows.Scan(&p.ID, &p.NamaPetugas, &p.Jabatan, &pid); err != nil {
			log.Println("Error scanning:", err)
			continue
		}
		if pid.Valid {
			pidVal := int(pid.Int64)
			p.ParentID = &pidVal
		}

		// RECURSIVE CALL: Ambil children dari petugas ini (increment depth)
		p.Children = getPetugasHierarchy(&p.ID, currentDepth+1, maxDepth, nama, jabatan)

		results = append(results, p)
	}
	return results
}

func createPetugas(c *gin.Context) {
	var p Petugas
	if err := c.BindJSON(&p); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	// ID Auto Increment
	_, err := db.Exec("INSERT INTO PetugasIzin (NamaPetugas, Jabatan) VALUES (?, ?)", p.NamaPetugas, p.Jabatan)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "Petugas created"})
}

func updatePetugas(c *gin.Context) {
	id := c.Param("id")
	var p Petugas
	if err := c.BindJSON(&p); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	_, err := db.Exec("UPDATE PetugasIzin SET NamaPetugas=?, Jabatan=? WHERE IDPetugas=?", p.NamaPetugas, p.Jabatan, id)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "Petugas updated"})
}

func deletePetugas(c *gin.Context) {
	id := c.Param("id")
	_, err := db.Exec("DELETE FROM PetugasIzin WHERE IDPetugas=?", id)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "Petugas deleted"})
}

// -- Barang Handlers (New) --

func createBarang(c *gin.Context) {
	var b Barang
	if err := c.BindJSON(&b); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	query := `INSERT INTO Barang (Nama, Jenis, Harga, Pajak, BeratBarang, SuratIzinID, TransportasiID, NegaraAsal, NegaraTujuan) 
	          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
	_, err := db.Exec(query, b.Nama, b.Jenis, b.Harga, b.Pajak, b.BeratBarang, b.SuratIzinID, b.TransportasiID, b.NegaraAsal, b.NegaraTujuan)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "Barang created"})
}

func updateBarang(c *gin.Context) {
	id := c.Param("id")
	var b Barang
	if err := c.BindJSON(&b); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	query := `UPDATE Barang SET Nama=?, Jenis=?, Harga=?, Pajak=?, BeratBarang=?, SuratIzinID=?, TransportasiID=?, NegaraAsal=?, NegaraTujuan=? 
	          WHERE ID=?`
	_, err := db.Exec(query, b.Nama, b.Jenis, b.Harga, b.Pajak, b.BeratBarang, b.SuratIzinID, b.TransportasiID, b.NegaraAsal, b.NegaraTujuan, id)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "Barang updated"})
}

func deleteBarang(c *gin.Context) {
	id := c.Param("id")
	_, err := db.Exec("DELETE FROM Barang WHERE ID=?", id)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, gin.H{"message": "Barang deleted"})
}

func getBarangStats(c *gin.Context) {
	log.Println("--- DEBUG: Fetching Stats ---")
	// 1. Top 5 destinations
	destQuery := `SELECT NegaraTujuan, SUM(Harga) as total FROM Barang GROUP BY NegaraTujuan ORDER BY total DESC LIMIT 5`
	destRows, err := db.Query(destQuery)
	destinationStats := make([]interface{}, 0)
	if err == nil {
		for destRows.Next() {
			var name string
			var value float64
			if err := destRows.Scan(&name, &value); err == nil {
				destinationStats = append(destinationStats, gin.H{"name": name, "value": value})
			}
		}
		destRows.Close()
	}

	// 2. Type distribution
	typeQuery := `SELECT Jenis, COUNT(*) as count FROM Barang GROUP BY Jenis`
	typeRows, err := db.Query(typeQuery)
	typeStats := make([]interface{}, 0)
	if err == nil {
		for typeRows.Next() {
			var name string
			var value int
			if err := typeRows.Scan(&name, &value); err == nil {
				typeStats = append(typeStats, gin.H{"name": name, "value": value})
			}
		}
		typeRows.Close()
	}

	// 3. Summary totals
	var totalValue sql.NullFloat64
	var totalItems int
	err = db.QueryRow("SELECT SUM(Harga), COUNT(*) FROM Barang").Scan(&totalValue, &totalItems)

	val := 0.0
	if err != nil {
		log.Println("Error fetching summary totals:", err)
		// Use default values if query fails
		totalItems = 0
	} else if totalValue.Valid {
		val = totalValue.Float64
	}

	// 4. Origin distribution per Type (New chart requirements)
	originTypeQuery := `SELECT Jenis, NegaraAsal, COUNT(*) as count FROM Barang GROUP BY Jenis, NegaraAsal`
	otRows, err := db.Query(originTypeQuery)
	originTypeStats := make([]interface{}, 0)
	if err == nil {
		for otRows.Next() {
			var jenis string
			var origin string
			var count int
			if err := otRows.Scan(&jenis, &origin, &count); err == nil {
				originTypeStats = append(originTypeStats, gin.H{
					"jenis":  jenis,
					"origin": origin,
					"count":  count,
				})
			}
		}
		otRows.Close()
	}

	log.Printf("DEBUG: Found %d dests, %d types, %d originType entries, TotalVal: %f, TotalItems: %d", len(destinationStats), len(typeStats), len(originTypeStats), val, totalItems)

	c.JSON(http.StatusOK, gin.H{
		"destinationStats": destinationStats,
		"typeStats":        typeStats,
		"originTypeStats":  originTypeStats,
		"totalValue":       val,
		"totalItems":       totalItems,
	})
}
