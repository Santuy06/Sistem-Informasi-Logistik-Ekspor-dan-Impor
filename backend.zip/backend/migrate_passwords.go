//go:build ignore

package main

import (
	"database/sql"
	"fmt"
	"log"

	_ "github.com/go-sql-driver/mysql"
	"golang.org/x/crypto/bcrypt"
)

func main() {
	// Connect to database
	dsn := "root:@tcp(127.0.0.1:3306)/ekspor_impor"
	db, err := sql.Open("mysql", dsn)
	if err != nil {
		log.Fatal("Error connecting to database: ", err)
	}
	defer db.Close()

	fmt.Println("🔐 Starting password migration to bcrypt...")

	// Fetch all users with plain-text passwords
	rows, err := db.Query("SELECT ID, Username, Password FROM Users")
	if err != nil {
		log.Fatal("Error fetching users: ", err)
	}
	defer rows.Close()

	type UserPassword struct {
		ID       int
		Username string
		Password string
	}

	var users []UserPassword
	for rows.Next() {
		var u UserPassword
		if err := rows.Scan(&u.ID, &u.Username, &u.Password); err != nil {
			log.Printf("Error scanning row: %v", err)
			continue
		}
		users = append(users, u)
	}

	fmt.Printf("Found %d users to migrate\n", len(users))

	// Hash each password and update
	for _, user := range users {
		// Check if already hashed (bcrypt hashes start with $2a$ or $2b$)
		if len(user.Password) > 4 && (user.Password[:4] == "$2a$" || user.Password[:4] == "$2b$") {
			fmt.Printf("⏭️  Skipping %s (already hashed)\n", user.Username)
			continue
		}

		// Hash the plain-text password
		hash, err := bcrypt.GenerateFromPassword([]byte(user.Password), 12)
		if err != nil {
			log.Printf("❌ Error hashing password for %s: %v", user.Username, err)
			continue
		}

		// Update database
		_, err = db.Exec("UPDATE Users SET Password=? WHERE ID=?", string(hash), user.ID)
		if err != nil {
			log.Printf("❌ Error updating password for %s: %v", user.Username, err)
			continue
		}

		fmt.Printf("✅ Migrated password for user: %s\n", user.Username)
	}

	fmt.Println("\n🎉 Password migration complete!")
	fmt.Println("ℹ️  All users can now login with their existing passwords (now securely hashed)")
}
