import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import ProtectedRoute from './components/ProtectedRoute';
import { ROLES } from './utils/constants';

import TransportasiPage from './pages/TransportasiPage';
import SuratIzinPage from './pages/SuratIzinPage';
import PetugasPage from './pages/PetugasPage';

function App() {
    return (
        <BrowserRouter>
            <Routes>
                <Route path="/login" element={<LoginPage />} />

                {/* Dashboard: All Roles */}
                <Route element={<ProtectedRoute allowedRoles={['Admin', 'Pemerintah', 'Staff', 'Masyarakat']} />}>
                    <Route path="/dashboard" element={<DashboardPage />} />
                </Route>

                {/* Master Data: Admin & Pemerintah */}
                <Route element={<ProtectedRoute allowedRoles={['Admin', 'Pemerintah']} />}>
                    <Route path="/transportasi" element={<TransportasiPage />} />
                    <Route path="/surat-izin" element={<SuratIzinPage />} />
                    <Route path="/petugas" element={<PetugasPage />} />
                </Route>


                {/* Default Redirect */}
                <Route path="/" element={<Navigate to="/dashboard" replace />} />
                <Route path="*" element={<Navigate to="/dashboard" replace />} />
            </Routes>
        </BrowserRouter>
    );
}

export default App;
