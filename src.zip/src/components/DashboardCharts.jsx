import React, { useMemo } from 'react';
import { Typography, Empty, Row, Col } from 'antd';
import {
    BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
    PieChart, Pie, Cell, Sector
} from 'recharts';

const { Title } = Typography;

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

const DashboardCharts = ({ tableData }) => {
    // Process tableData to format it for BarChart
    // Group by 'origin' (X-axis) and stack by 'type'
    const chartData = useMemo(() => {
        if (!tableData || !Array.isArray(tableData)) return [];
        const grouped = tableData.reduce((acc, curr) => {
            const country = curr.origin || 'Unknown';
            const type = curr.type || 'Other';

            if (!acc[country]) {
                acc[country] = { name: country };
            }
            acc[country][type] = (acc[country][type] || 0) + 1;
            return acc;
        }, {});
        return Object.values(grouped);
    }, [tableData]);

    // Unique types for dynamic bars/legend
    const types = useMemo(() => {
        if (!tableData || !Array.isArray(tableData)) return [];
        const set = new Set();
        tableData.forEach(item => {
            if (item.type) set.add(item.type);
        });
        return Array.from(set);
    }, [tableData]);

    if (!tableData || tableData.length === 0) {
        return <Empty description="Tidak ada data di halaman ini untuk dianalisis" style={{ padding: '60px 0' }} />;
    }

    return (
        <div style={{ padding: '10px' }}>
            <Title level={5} style={{ marginBottom: 24, textAlign: 'center', color: '#002766' }}>
                DISTRIBUSI JENIS BARANG PER NEGARA ASAL
            </Title>
            <div style={{ height: 500, width: '100%' }}>
                <ResponsiveContainer>
                    <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                        <XAxis
                            dataKey="name"
                            angle={-45}
                            textAnchor="end"
                            interval={0}
                            height={80}
                            label={{ value: 'Negara Asal', position: 'insideBottom', offset: -40 }}
                        />
                        <YAxis label={{ value: 'Jumlah Unit', angle: -90, position: 'insideLeft' }} />
                        <Tooltip
                            cursor={{ fill: 'transparent' }}
                            contentStyle={{ borderRadius: 12, border: 'none', boxShadow: '0 8px 24px rgba(0,0,0,0.15)' }}
                        />
                        <Legend verticalAlign="top" height={36} />
                        {types.map((type, index) => (
                            <Bar
                                key={type}
                                dataKey={type}
                                stackId="a"
                                fill={COLORS[index % COLORS.length]}
                                radius={[0, 0, 0, 0]}
                                barSize={40}
                            />
                        ))}
                    </BarChart>
                </ResponsiveContainer>
            </div>
        </div>
    );
};

export default React.memo(DashboardCharts);
