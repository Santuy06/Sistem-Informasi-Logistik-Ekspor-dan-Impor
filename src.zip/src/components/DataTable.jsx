import React, { useMemo } from 'react';
import { Table, Button, Space, Tag, Popconfirm } from 'antd';
import { EditOutlined, DeleteOutlined } from '@ant-design/icons';
import { useAuth } from '../context/AuthContext';
import { ROLES } from '../utils/constants';

const DataTable = ({ data, loading, pagination, onChange, onDelete, onEdit }) => {
    const { role } = useAuth();
    const canEdit = ['Admin', 'Staff'].includes(role);
    const canDelete = role === 'Admin';

    const columns = useMemo(() => [
        {
            title: 'Nama Barang',
            dataIndex: 'name',
            key: 'name',
        },
        {
            title: 'Jenis',
            dataIndex: 'type',
            key: 'type',
            render: (type) => {
                let color = 'geekblue';
                if (type === 'Tekstil') color = 'green';
                if (type === 'Makanan') color = 'orange';
                return <Tag color={color}>{type.toUpperCase()}</Tag>;
            }
        },
        {
            title: 'Negara Asal',
            dataIndex: 'origin',
            key: 'origin',
        },
        {
            title: 'Negara Tujuan',
            dataIndex: 'destination',
            key: 'destination',
        },
        {
            title: 'Harga',
            dataIndex: 'price',
            key: 'price',
            render: (text) => `Rp ${text.toLocaleString('id-ID')}`,
        },
        {
            title: 'Aksi',
            key: 'action',
            render: (_, record) => (
                <Space size="middle">
                    {canEdit && (
                        <Button
                            type="link"
                            icon={<EditOutlined />}
                            onClick={() => onEdit(record)}
                        >
                            Edit
                        </Button>
                    )}
                    {canDelete && (
                        <Popconfirm
                            title="Hapus Data"
                            description="Apakah Anda yakin ingin menghapus barang ini?"
                            onConfirm={() => onDelete(record.id)}
                            okText="Ya"
                            cancelText="Tidak"
                        >
                            <Button type="link" danger icon={<DeleteOutlined />}>
                                Hapus
                            </Button>
                        </Popconfirm>
                    )}
                </Space>
            ),
        },
    ], [canEdit, canDelete, onEdit, onDelete]);

    const secureColumns = useMemo(() => {
        const showAction = [ROLES.ADMIN, 'Staff'].includes(role);

        return columns
            .filter(col => {
                if (col.key === 'action' && !showAction) return false;
                return true;
            })
            .map(col => {
                if (col.key === 'price' && role === ROLES.VIEWER) {
                    return { ...col, render: () => <span style={{ color: '#ccc' }}>Confidential</span> };
                }
                return col;
            });
    }, [columns, role]);

    return (
        <Table
            bordered
            size="middle"
            columns={secureColumns}
            dataSource={data}
            rowKey="id"
            scroll={{ x: 'max-content' }}
            pagination={{
                current: pagination.current,
                pageSize: pagination.pageSize,
                total: pagination.total,
                position: ['bottomCenter'],
                showSizeChanger: true,
                showQuickJumper: true,
                pageSizeOptions: ['5', '10', '20', '50'],
                showTotal: (total, range) => `Menampilkan ${range[0]}-${range[1]} dari ${total.toLocaleString('id-ID')} data`,
                style: { marginTop: 24, marginBottom: 24 }
            }}
            loading={loading}
            onChange={onChange}
            rowClassName={(record, index) => index % 2 === 0 ? 'table-row-light' : 'table-row-dark'}
        />
    );
};

export default DataTable;