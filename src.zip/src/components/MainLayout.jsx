import React from 'react';
import { Layout, Button, Typography, Menu, Row, Col } from 'antd';
import {
    LogoutOutlined,
    DashboardOutlined,
    CarOutlined,
    FileProtectOutlined,
    UserSwitchOutlined
} from '@ant-design/icons';
import { useAuth } from '../context/AuthContext';
import { useNavigate, useLocation } from 'react-router-dom';

const { Header, Content, Footer } = Layout;
const { Text } = Typography;

const MainLayout = ({ children }) => {
    const { user, role, logout } = useAuth();
    const navigate = useNavigate();
    const location = useLocation();

    // Menu Items
    const menuItems = [
        { key: '/dashboard', label: 'BERANDA', icon: <DashboardOutlined /> },
    ];

    if (role === 'Admin' || role === 'Pemerintah') {
        menuItems.push(
            { key: '/transportasi', label: 'TRANSPORTASI', icon: <CarOutlined /> },
            { key: '/surat-izin', label: 'SURAT IZIN', icon: <FileProtectOutlined /> },
            { key: '/petugas', label: 'DATA PETUGAS', icon: <UserSwitchOutlined /> }
        );
    }

    return (
        <Layout className="layout" style={{ minHeight: '100vh' }}>
            <Header style={{ display: 'flex', alignItems: 'center', background: '#fff', boxShadow: '0 2px 8px #f0f1f2', position: 'sticky', top: 0, zIndex: 10, padding: '0 50px' }}>
                <div style={{ display: 'flex', alignItems: 'center', marginRight: 40 }}>
                    <div style={{ width: 32, height: 32, background: 'linear-gradient(135deg, #1890ff 0%, #36cfc9 100%)', borderRadius: 4, marginRight: 10 }}></div>
                    <Text style={{ fontSize: 18, fontWeight: '800', color: '#002766', letterSpacing: '1px' }}>SATU DATA</Text>
                </div>

                <Menu
                    theme="light"
                    mode="horizontal"
                    selectedKeys={[location.pathname]}
                    items={menuItems}
                    onClick={({ key }) => navigate(key)}
                    style={{ flex: 1, borderBottom: 'none', fontWeight: 500 }}
                />

                <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
                    <div style={{ textAlign: 'right', lineHeight: '1.2' }}>
                        <Text strong style={{ display: 'block' }}>{user?.username}</Text>
                        <Text type="secondary" style={{ fontSize: 12 }}>{role}</Text>
                    </div>
                    <Button type="primary" shape="round" icon={<LogoutOutlined />} onClick={logout} danger>Logout</Button>
                </div>
            </Header>

            <Content style={{ padding: '24px 50px', maxWidth: 1400, margin: '0 auto', width: '100%' }}>
                {children}
            </Content>

            <Footer style={{ textAlign: 'center', background: '#001529', color: 'rgba(255,255,255,0.45)', padding: '24px 50px' }}>
                Sistem Ekspor Impor ©2025
            </Footer>
        </Layout>
    );
};

export default MainLayout;
