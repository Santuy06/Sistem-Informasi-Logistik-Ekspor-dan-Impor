import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const ProtectedRoute = ({ allowedRoles }) => {
    const { user, role, loading } = useAuth();

    if (loading) {
        return <div>Loading...</div>; // Or a proper Spinner
    }

    if (!user) {
        return <Navigate to="/login" replace />;
    }

    if (allowedRoles && !allowedRoles.includes(role)) {
        return (
            <div style={{ textAlign: 'center', marginTop: '50px' }}>
                <h1>403 Forbidden</h1>
                <p>You do not have permission to access this page.</p>
            </div>
        );
    }

    return <Outlet />;
};

export default ProtectedRoute;
