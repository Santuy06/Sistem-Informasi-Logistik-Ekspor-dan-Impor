import React from 'react';
import { Form, Input, Select, Button, Row, Col, Card } from 'antd';
import { SearchOutlined, ReloadOutlined } from '@ant-design/icons';

const { Option } = Select;

const SearchForm = ({ onSearch, initialValues }) => {
    const [form] = Form.useForm();

    const handleFinish = (values) => {
        onSearch(values);
    };

    const handleReset = () => {
        form.resetFields();
        onSearch({});
    };

    return (
        <Form
            form={form}
            layout="vertical"
            onFinish={handleFinish}
            initialValues={initialValues}
        >
            <Form.Item name="name" label="Nama Barang">
                <Input placeholder="Cari nama barang..." autoComplete="off" />
            </Form.Item>
            <Form.Item name="type" label="Jenis Barang">
                <Select placeholder="Pilih jenis" allowClear>
                    <Select.Option value="Elektronik">Elektronik</Select.Option>
                    <Select.Option value="Tekstil">Tekstil</Select.Option>
                    <Select.Option value="Makanan">Makanan</Select.Option>
                    <Select.Option value="Otomotif">Otomotif</Select.Option>
                </Select>
            </Form.Item>
            <Form.Item name="origin" label="Negara Asal">
                <Input placeholder="Contoh: Indonesia" autoComplete="off" />
            </Form.Item>
            <Form.Item name="destination" label="Negara Tujuan">
                <Input placeholder="Contoh: Amerika" autoComplete="off" />
            </Form.Item>

            <div style={{ textAlign: 'right', marginTop: 16 }}>
                <Button onClick={handleReset} icon={<ReloadOutlined />} style={{ marginRight: 8 }} block>
                    Reset
                </Button>
                <Button type="primary" htmlType="submit" icon={<SearchOutlined />} block style={{ marginTop: 8 }}>
                    Terapkan Filter
                </Button>
            </div>
        </Form>
    );
};

export default React.memo(SearchForm);
