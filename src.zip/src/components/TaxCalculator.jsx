import React, { useState } from 'react';
import { Card, Form, InputNumber, Select, Row, Col, Typography, Spin, Alert, Divider, Space } from 'antd';
import { SyncOutlined } from '@ant-design/icons';
import axios from 'axios';

const { Title, Text } = Typography;
const { Option } = Select;

const TaxCalculator = () => {
    const [form] = Form.useForm();
    const [loading, setLoading] = useState(false);
    const [results, setResults] = useState(null);

    const onValuesChange = async (_, allValues) => {
        if (!allValues.price || allValues.price <= 0) {
            setResults(null);
            return;
        }

        setLoading(true);
        try {
            const response = await axios.post('/api/estimasi', {
                activity: allValues.activity || 'Impor',
                price: allValues.price,
                type: allValues.type || 'Lainnya',
                origin: allValues.origin || 'Indonesia',
                destination: allValues.destination || 'Indonesia'
            });
            setResults(response.data);
        } catch (error) {
            console.error("Calculation Error:", error);
            setResults(null);
        } finally {
            setLoading(false);
        }
    };

    return (
        <Card
            title={
                <Space>
                    <SyncOutlined spin={loading} style={{ display: loading ? 'inline-block' : 'none' }} />
                    <span>Kalkulator Estimasi Biaya Perdagangan</span>
                </Space>
            }
            style={{ borderRadius: 12, boxShadow: '0 4px 12px rgba(0,0,0,0.05)' }}
        >
            <Form
                form={form}
                layout="vertical"
                onValuesChange={onValuesChange}
                initialValues={{ activity: 'Impor', origin: 'Indonesia', destination: 'China', type: 'Elektronik' }}
            >
                <Row gutter={16}>
                    <Col xs={24} md={12}>
                        <Form.Item label="Aktivitas Perdagangan" name="activity">
                            <Select style={{ width: '100%' }}>
                                <Option value="Impor">Impor</Option>
                                <Option value="Ekspor">Ekspor</Option>
                            </Select>
                        </Form.Item>
                    </Col>
                    <Col xs={24} md={12}>
                        <Form.Item label="Harga Barang (IDR)" name="price">
                            <InputNumber
                                style={{ width: '100%' }}
                                formatter={value => `${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
                                parser={value => value.replace(/(,*)/g, '')}
                                min={0}
                                prefix="Rp"
                                placeholder="Masukkan Harga"
                            />
                        </Form.Item>
                    </Col>
                </Row>

                <Row gutter={16}>
                    <Col xs={24} md={8}>
                        <Form.Item label="Jenis Barang" name="type">
                            <Select placeholder="Pilih Jenis">
                                <Option value="Elektronik">Elektronik (Premium)</Option>
                                <Option value="Tekstil">Tekstil</Option>
                                <Option value="Makanan">Makanan</Option>
                                <Option value="Otomotif">Otomotif (Luxury)</Option>
                                <Option value="Obat">Obat-obatan (Subsidi)</Option>
                                <Option value="Lainnya">Lainnya</Option>
                            </Select>
                        </Form.Item>
                    </Col>
                    <Col xs={12} md={8}>
                        <Form.Item label="Negara Asal" name="origin">
                            <Select showSearch placeholder="Asal">
                                <Option value="Indonesia">Indonesia</Option>
                                <Option value="China">China</Option>
                                <Option value="Amerika">Amerika Serikat</Option>
                                <Option value="Jepang">Jepang</Option>
                                <Option value="Singapura">Singapura</Option>
                                <Option value="Vietnam">Vietnam</Option>
                            </Select>
                        </Form.Item>
                    </Col>
                    <Col xs={12} md={8}>
                        <Form.Item label="Negara Tujuan" name="destination">
                            <Select showSearch placeholder="Tujuan">
                                <Option value="Indonesia">Indonesia</Option>
                                <Option value="China">China</Option>
                                <Option value="Amerika">Amerika Serikat</Option>
                                <Option value="Jepang">Jepang</Option>
                                <Option value="Singapura">Singapura</Option>
                                <Option value="Vietnam">Vietnam</Option>
                            </Select>
                        </Form.Item>
                    </Col>
                </Row>

                {results ? (
                    <div style={{ background: '#f0f5ff', padding: '20px', borderRadius: '12px', marginTop: 10, border: '1px solid #adc6ff' }}>
                        <Title level={5} style={{ marginTop: 0 }}>Hasil Estimasi ({results.activity})</Title>
                        <Divider style={{ margin: '12px 0' }} />
                        <Row gutter={16}>
                            <Col span={8}>
                                <Text type="secondary">Pajak Applied ({results.pajak_persen?.toFixed(1)}%)</Text>
                                <Title level={4}>Rp {results.pajak_nilai?.toLocaleString('id-ID')}</Title>
                            </Col>
                            <Col span={8}>
                                <Text type="secondary">Logistik & Transport</Text>
                                <Title level={4}>Rp {results.biaya_transport?.toLocaleString('id-ID')}</Title>
                            </Col>
                            <Col span={8}>
                                <Text type="secondary">Total Estimasi Keseluruhan</Text>
                                <Title level={3} type="success">Rp {results.total_biaya?.toLocaleString('id-ID')}</Title>
                            </Col>
                        </Row>
                        <Alert
                            message={results.info}
                            type="info"
                            showIcon
                            style={{ marginTop: 15, borderRadius: 8 }}
                        />
                    </div>
                ) : (
                    <div style={{ textAlign: 'center', padding: '40px', background: '#fafafa', borderRadius: 8, border: '1px dashed #d9d9d9' }}>
                        <Text type="secondary">Masukkan harga barang untuk melihat estimasi biaya otomatis berkas pajak & logistik.</Text>
                    </div>
                )}
            </Form>
        </Card>
    );
};

export default TaxCalculator;
