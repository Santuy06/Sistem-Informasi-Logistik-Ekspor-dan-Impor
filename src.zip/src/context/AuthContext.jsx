import { createContext, useState, useEffect, useContext } from 'react';
import { mockLogin } from '../services/api';
import { jwtDecode } from 'jwt-decode';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);
    const [role, setRole] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // Check for existing token
        const token = localStorage.getItem('token');
        if (token) {
            try {
                // In a real app, verify signature. Here we just decode payload.
                // Our mock token payload is base64 encoded JSON at index 1
                const payloadPart = token.split('.')[1];
                if (payloadPart) {
                    const decoded = JSON.parse(atob(payloadPart));
                    // Mock token has no expiration. Trust it if it decodes.
                    setUser({ username: decoded.username });
                    setRole(decoded.role);
                }
            } catch (error) {
                console.error("Invalid token", error);
                logout();
            }
        }
        setLoading(false);
    }, []);

    const login = async (username, password) => {
        try {
            const data = await mockLogin(username, password);
            localStorage.setItem('token', data.token);
            setUser({ username: data.username || username });
            setRole(data.role);
            return true;
        } catch (error) {
            console.error("Login failed", error);
            throw error;
        }
    };

    const logout = () => {
        localStorage.removeItem('token');
        setUser(null);
        setRole(null);
    };

    return (
        <AuthContext.Provider value={{ user, role, login, logout, loading }}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = () => useContext(AuthContext);
