import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { message, Typography, Row, Col, Card, Spin, Modal, Form, Input, InputNumber, Select } from 'antd';
import { fetchItems, fetchBarangStats } from '../services/api';
import SearchForm from '../components/SearchForm';
import DataTable from '../components/DataTable';
import TaxCalculator from '../components/TaxCalculator';
import DashboardCharts from '../components/DashboardCharts';
import MainLayout from '../components/MainLayout';

const { Title, Text } = Typography;
const { Option } = Select;

const DashboardPage = () => {
    const [tableData, setTableData] = useState([]);
    const [stats, setStats] = useState(null);
    const [tableLoading, setTableLoading] = useState(false);
    const [statsLoading, setStatsLoading] = useState(false);
    const [filters, setFilters] = useState({});
    const [pagination, setPagination] = useState({
        current: 1,
        pageSize: 10,
        total: 0
    });
    const [isModalVisible, setIsModalVisible] = useState(false);
    const [editingItem, setEditingItem] = useState(null);
    const [form] = Form.useForm();

    // Integrated Loaders
    const loadAll = useCallback(async (page = 1, pageSize = 10, currentFilters = {}) => {
        setTableLoading(true);
        setStatsLoading(true);

        try {
            // Parallel fetch for speed
            const [tableRes, statsRes] = await Promise.all([
                fetchItems(page, pageSize, currentFilters),
                fetchBarangStats()
            ]);

            setTableData(tableRes.data || []);
            setPagination({
                current: Number(tableRes.page) || page,
                pageSize: Number(tableRes.pageSize) || pageSize,
                total: Number(tableRes.total) || 0
            });
            setStats(statsRes);
        } catch (err) {
            console.error("Dashboard Load Error:", err);
            message.error("Gagal memuat data dashboard (Cek koneksi backend)");
        } finally {
            setTableLoading(false);
            setStatsLoading(false);
        }
    }, []);

    useEffect(() => {
        loadAll(1, 10, {});
    }, [loadAll]);

    // Handlers
    const handleSearch = (values) => {
        setFilters(values);
        loadAll(1, pagination.pageSize, values);
    };

    const handleTableChange = (newPagination) => {
        loadAll(newPagination.current, newPagination.pageSize, filters);
    };

    const handleEdit = (record) => {
        setEditingItem(record);
        form.setFieldsValue({
            name: record.name,
            type: record.type,
            price: record.price,
            origin: record.origin,
            destination: record.destination
        });
        setIsModalVisible(true);
    };

    const handleDelete = (id) => {
        try {
            // MODE MOCK: Hapus hanya dari state lokal, tidak menyentuh database
            const newData = tableData.filter(item => item.id !== id);
            setTableData(newData);

            // Update pagination total
            setPagination(prev => ({
                ...prev,
                total: prev.total - 1
            }));

            message.success('Barang berhasil dihapus (simulasi - database tidak terpengaruh)');
        } catch (error) {
            message.error('Gagal menghapus barang');
        }
    };

    const handleModalOk = async () => {
        try {
            const values = await form.validateFields();
            if (editingItem) {
                // MODE MOCK: Update hanya di state lokal, tidak menyentuh database
                const newData = tableData.map(item =>
                    item.id === editingItem.id ? { ...item, ...values } : item
                );
                setTableData(newData);
                message.success('Barang berhasil diperbarui (simulasi - database tidak terpengaruh)');
            }
            setIsModalVisible(false);
            form.resetFields();
        } catch (error) {
            console.error(error);
            message.error('Gagal menyimpan data');
        }
    };

    const handleModalCancel = () => {
        setIsModalVisible(false);
        form.resetFields();
    };

    return (
        <MainLayout>
            {/* 1. SINGLE HEADER AREA */}
            <div style={{ marginBottom: 32, borderBottom: '2px solid #f0f0f0', paddingBottom: 16 }}>
                <Title level={2} style={{ color: '#002766', margin: 0, fontWeight: 800 }}>
                    PORTAL MONITORING PERDAGANGAN INTERNASIONAL
                </Title>
            </div>

            {/* 2. STATS SUMMARY (DYNAMICALLY CALCULATED FROM CURRENT PAGE) */}
            <Row gutter={[24, 24]} style={{ marginBottom: 24 }}>
                <Col xs={24} sm={12}>
                    <Card bordered={false} bodyStyle={{ padding: '24px' }} style={{ borderRadius: 12, boxShadow: '0 4px 12px rgba(0,0,0,0.05)' }}>
                        <Text type="secondary" strong>TOTAL NILAI EKSPOR</Text>
                        <Title level={2} style={{ margin: '12px 0 0 0', color: '#1890ff' }}>
                            {tableLoading ? <Spin size="small" /> : `Rp ${(Array.isArray(tableData) ? tableData : []).reduce((sum, item) => sum + (item.price || 0), 0).toLocaleString('id-ID')}`}
                        </Title>
                    </Card>
                </Col>
                <Col xs={24} sm={12}>
                    <Card bordered={false} bodyStyle={{ padding: '24px' }} style={{ borderRadius: 12, boxShadow: '0 4px 12px rgba(0,0,0,0.05)', borderLeft: '6px solid #52c41a' }}>
                        <Text type="secondary" strong>TOTAL VOLUME BARANG</Text>
                        <Title level={2} style={{ margin: '12px 0 0 0', color: '#52c41a' }}>
                            {tableLoading ? <Spin size="small" /> : `${tableData.length} Unit`}
                        </Title>
                    </Card>
                </Col>
            </Row>

            {/* 3. MAIN CONTENT AREA (FULL WIDTH) */}
            <Row gutter={[24, 24]}>
                <Col span={24}>
                    <Card bordered={false} style={{ borderRadius: 12, marginBottom: 24 }}>
                        <Spin spinning={tableLoading} tip="Menganalisis Tren Data Halaman Ini...">
                            {/* Pass tableData directly so it reflects the current page */}
                            <DashboardCharts tableData={tableData} />
                        </Spin>
                    </Card>
                </Col>
            </Row>

            <Row gutter={[24, 24]}>
                <Col span={24}>
                    {/* Filters */}
                    <Card title="Filter Pencarian" bordered={false} style={{ borderRadius: 12, marginBottom: 24 }}>
                        <SearchForm onSearch={handleSearch} />
                    </Card>

                    <Card
                        title={<Title level={4} style={{ margin: 0, color: '#002766' }}>DETAIL TRANSAKSI</Title>}
                        bordered={false}
                        style={{ borderRadius: 12, overflow: 'hidden', marginBottom: 24 }}
                        bodyStyle={{ padding: 0 }}
                    >
                        <DataTable
                            data={tableData}
                            loading={tableLoading}
                            pagination={pagination}
                            onChange={handleTableChange}
                            onEdit={handleEdit}
                            onDelete={handleDelete}
                        />
                    </Card>

                    {/* Tax Calculator */}
                    <div style={{ background: '#fff', padding: '24px', borderRadius: 12, boxShadow: '0 2px 8px rgba(0,0,0,0.06)' }}>
                        <Title level={4} style={{ marginBottom: 16, color: '#002766' }}>Kalkulator Pajak & Bea Cukai</Title>
                        <TaxCalculator />
                    </div>
                </Col>
            </Row>

            {/* Modal Edit Barang */}
            <Modal
                title="Edit Barang"
                open={isModalVisible}
                onOk={handleModalOk}
                onCancel={handleModalCancel}
                okText="Simpan"
                cancelText="Batal"
                width={600}
            >
                <Form form={form} layout="vertical">
                    <Form.Item name="name" label="Nama Barang" rules={[{ required: true, message: 'Nama barang wajib diisi' }]}>
                        <Input placeholder="Nama Barang" />
                    </Form.Item>
                    <Form.Item name="type" label="Jenis Barang" rules={[{ required: true, message: 'Jenis barang wajib dipilih' }]}>
                        <Select placeholder="Pilih Jenis">
                            <Option value="Elektronik">Elektronik</Option>
                            <Option value="Tekstil">Tekstil</Option>
                            <Option value="Makanan">Makanan</Option>
                            <Option value="Otomotif">Otomotif</Option>
                            <Option value="Obat">Obat</Option>
                        </Select>
                    </Form.Item>
                    <Form.Item name="price" label="Harga" rules={[{ required: true, message: 'Harga wajib diisi' }]}>
                        <InputNumber
                            style={{ width: '100%' }}
                            formatter={value => `Rp ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
                            parser={value => value.replace(/Rp\s?|(,*)/g, '')}
                            min={0}
                        />
                    </Form.Item>
                    <Form.Item name="origin" label="Negara Asal" rules={[{ required: true, message: 'Negara asal wajib diisi' }]}>
                        <Input placeholder="Contoh: Indonesia" />
                    </Form.Item>
                    <Form.Item name="destination" label="Negara Tujuan" rules={[{ required: true, message: 'Negara tujuan wajib diisi' }]}>
                        <Input placeholder="Contoh: China" />
                    </Form.Item>
                </Form>
            </Modal>
        </MainLayout>
    );
};

export default DashboardPage;
