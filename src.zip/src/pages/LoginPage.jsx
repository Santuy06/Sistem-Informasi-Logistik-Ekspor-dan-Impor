import { useState } from 'react';
import { Form, Input, Button, Card, Typography, Alert, message } from 'antd';
import { UserOutlined, LockOutlined } from '@ant-design/icons';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const { Title, Text } = Typography;

const LoginPage = () => {
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const { login } = useAuth();
    const navigate = useNavigate();

    const onFinish = async (values) => {
        setLoading(true);
        setError('');
        try {
            await login(values.username, values.password);
            message.success('Login successful');
            navigate('/dashboard');
        } catch (err) {
            setError('Invalid username or password');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="app-background" style={{
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            minHeight: '100vh',
        }}>
            <Card style={{
                width: 400,
                boxShadow: '0 8px 32px rgba(0,0,0,0.1)',
                background: 'rgba(255, 255, 255, 0.9)',
                backdropFilter: 'blur(8px)',
                borderRadius: 12,
                border: '1px solid rgba(255, 255, 255, 0.3)'
            }}>
                <div style={{ textAlign: 'center', marginBottom: 20 }}>
                    <Title level={3}>Sistem Ekspor Impor</Title>
                    <Text type="secondary">Login to your account</Text>
                </div>

                {error && <Alert message={error} type="error" showIcon style={{ marginBottom: 20 }} />}

                <Form
                    name="login"
                    initialValues={{ remember: true }}
                    onFinish={onFinish}
                    layout="vertical"
                >
                    <Form.Item
                        name="username"
                        rules={[{ required: true, message: 'Please input your Username!', }]}
                    >
                        <Input
                            prefix={<UserOutlined />}
                            placeholder="Username (e.g. admin, pemerintah)"
                            autoComplete="off"
                        />
                    </Form.Item>

                    <Form.Item
                        name="password"
                        rules={[{ required: true, message: 'Please input your Password!' }]}
                    >
                        <Input.Password prefix={<LockOutlined />} placeholder="Password" />
                    </Form.Item>

                    <Form.Item>
                        <Button type="primary" htmlType="submit" loading={loading} block size="large">
                            Log in
                        </Button>
                    </Form.Item>

                    <div style={{ marginTop: 10, fontSize: '12px', color: '#888' }}>
                        <p>Demo Credentials:</p>
                        <ul>
                            <li>admin / admin123 (Admin)</li>
                            <li>pemerintah / pem123 (Pemerintah)</li>
                            <li>staff / staff123 (Staff)</li>
                            <li>user / user123 (Masyarakat)</li>
                        </ul>
                    </div>
                </Form>
            </Card>
        </div>
    );
};

export default LoginPage;
