import React, { useState, useEffect } from 'react';
import { Table, Button, Modal, Form, Input, message, Typography, Space, Card, Row, Col, Popconfirm, Tree } from 'antd';
import { PlusOutlined, EditOutlined, DeleteOutlined, SearchOutlined, ReloadOutlined } from '@ant-design/icons';
import { fetchMasterData, createMasterData, updateMasterData, deleteMasterData } from '../services/api';
import MainLayout from '../components/MainLayout';

import { useAuth } from '../context/AuthContext';

const { Title } = Typography;

// Component untuk tampilan tree rekursif
const PetugasTreeNode = ({ petugas, level, canEdit, canDelete, onEdit, onDelete }) => {
    return (
        <div style={{ marginLeft: level * 30, marginBottom: 12, padding: '12px', backgroundColor: '#fafafa', borderRadius: '8px', borderLeft: `4px solid ${level === 0 ? '#1890ff' : '#d9d9d9'}` }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                    <Typography.Text strong>{petugas.nama_petugas}</Typography.Text>
                    <Typography.Text type="secondary" style={{ marginLeft: 12 }}>({petugas.jabatan})</Typography.Text>
                </div>
                <Space>
                    {canEdit && (
                        <Button type="link" size="small" icon={<EditOutlined />} onClick={() => onEdit(petugas)}>
                            Edit
                        </Button>
                    )}
                    {canDelete && (
                        <Popconfirm
                            title="Hapus Data"
                            description="Apakah Anda yakin ingin menghapus petugas ini?"
                            onConfirm={() => onDelete(petugas.id)}
                            okText="Ya"
                            cancelText="Tidak"
                        >
                            <Button type="link" danger size="small" icon={<DeleteOutlined />}>Hapus</Button>
                        </Popconfirm>
                    )}
                </Space>
            </div>
            {petugas.children && petugas.children.length > 0 && (
                <div style={{ marginTop: 12 }}>
                    {petugas.children.map(child => (
                        <PetugasTreeNode key={child.id} petugas={child} level={level + 1} canEdit={canEdit} canDelete={canDelete} onEdit={onEdit} onDelete={onDelete} />
                    ))}
                </div>
            )}
        </div>
    );
};

const PetugasPage = () => {
    const { role } = useAuth();
    const canEdit = ['Admin', 'Staff'].includes(role);
    const canDelete = role === 'Admin';

    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(false);
    const [isModalVisible, setIsModalVisible] = useState(false);
    const [editingItem, setEditingItem] = useState(null);
    const [viewMode, setViewMode] = useState('iteratif');
    const [form] = Form.useForm();
    const [searchForm] = Form.useForm();

    // Pagination & Search State
    const [pagination, setPagination] = useState({ current: 1, pageSize: 10, total: 0 });
    const [filters, setFilters] = useState({ nama: '', jabatan: '' });

    const loadData = async (params = {}) => {
        setLoading(true);
        try {
            const page = params.page || pagination.current;
            const pageSize = params.pageSize || pagination.pageSize;
            const nama = params.nama !== undefined ? params.nama : filters.nama;
            const jabatan = params.jabatan !== undefined ? params.jabatan : filters.jabatan;

            const method = viewMode === 'rekursif' ? 'rekursif' : 'iteratif';
            let url = `/petugas?method=${method}&page=${page}&pageSize=${pageSize}`;

            if (nama) url += `&nama=${encodeURIComponent(nama)}`;
            if (jabatan) url += `&jabatan=${encodeURIComponent(jabatan)}`;

            const result = await fetchMasterData(url);

            if (method === 'iteratif' && result?.data) {
                setData(result.data || []);
                setPagination({
                    ...pagination,
                    current: page,
                    pageSize: pageSize,
                    total: result.total || 0,
                });
            } else if (method === 'rekursif' && result?.data) {
                setData(result.data || []);
            } else {
                setData(result || []);
            }
        } catch (error) {
            message.error('Gagal memuat data petugas');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadData({ page: 1 });
    }, [viewMode]);

    const handleSearch = (values) => {
        setFilters(values);
        loadData({ ...values, page: 1 });
    };

    const handleReset = () => {
        searchForm.resetFields();
        setFilters({ nama: '', jabatan: '' });
        loadData({ nama: '', jabatan: '', page: 1 });
    };

    const handleTableChange = (newPagination) => {
        loadData({
            page: newPagination.current,
            pageSize: newPagination.pageSize
        });
    };

    const handleEdit = (record) => {
        setEditingItem(record);
        form.setFieldsValue(record);
        setIsModalVisible(true);
    };

    const handleDelete = async (id) => {
        try {
            // Dalam sistem asli, ini akan panggil deleteMasterData(`/petugas/${id}`)
            // Untuk simulasi ini agar data tidak hilang di 500k records, kita hanya kasih notif
            message.success('Request hapus dikirim (Database dilindungi)');
        } catch (error) {
            message.error('Gagal menghapus petugas');
        }
    };

    const handleOk = async () => {
        try {
            const values = await form.validateFields();
            if (editingItem) {
                message.success('Petugas diperbarui (simulasi)');
            }
            setIsModalVisible(false);
        } catch (error) {
            console.error(error);
            message.error('Gagal menyimpan data');
        }
    };

    const columns = [
        { title: 'ID', dataIndex: 'id', key: 'id' },
        { title: 'Nama Petugas', dataIndex: 'nama_petugas', key: 'nama_petugas' },
        { title: 'Jabatan', dataIndex: 'jabatan', key: 'jabatan' },
        viewMode === 'rekursif' && {
            title: 'Level',
            key: 'level',
            render: (_, record) => record.parent_id ? 'Subordinat' : 'Kepala',
        },
        {
            title: 'Aksi',
            key: 'aksi',
            render: (_, record) => (
                <Space>
                    {canEdit && (
                        <Button type="link" icon={<EditOutlined />} onClick={() => handleEdit(record)}>
                            Edit
                        </Button>
                    )}
                    {canDelete && (
                        <Popconfirm
                            title="Hapus Data"
                            description="Apakah Anda yakin ingin menghapus petugas ini?"
                            onConfirm={() => handleDelete(record.id)}
                            okText="Ya"
                            cancelText="Tidak"
                        >
                            <Button type="link" danger icon={<DeleteOutlined />}>Hapus</Button>
                        </Popconfirm>
                    )}
                </Space>
            ),
        },
    ].filter(Boolean);

    const showAction = canEdit || canDelete;
    const visibleColumns = columns.filter(col => {
        if (col.key === 'aksi' && !showAction) return false;
        return true;
    });

    return (
        <MainLayout>
            <div style={{ marginBottom: 24 }}>
                <Title level={2} style={{ color: '#002766', margin: 0 }}>Kelola Data Petugas</Title>
                <Typography.Text type="secondary">Manajemen administrasi petugas lapangan</Typography.Text>
            </div>

            <Card
                title="Pencarian Petugas"
                extra={
                    <Space>
                        <Button
                            type={viewMode === 'iteratif' ? 'primary' : 'default'}
                            onClick={() => setViewMode('iteratif')}
                        >
                            Iteratif (List)
                        </Button>
                        <Button
                            type={viewMode === 'rekursif' ? 'primary' : 'default'}
                            onClick={() => setViewMode('rekursif')}
                        >
                            Rekursif (Hirarki)
                        </Button>
                    </Space>
                }
                style={{ marginBottom: 20 }}
            >
                <Form form={searchForm} layout="vertical" onFinish={handleSearch}>
                    <Row gutter={16}>
                        <Col span={10}>
                            <Form.Item name="nama" label="Nama Petugas">
                                <Input placeholder="Cari Nama..." prefix={<SearchOutlined />} />
                            </Form.Item>
                        </Col>
                        <Col span={10}>
                            <Form.Item name="jabatan" label="Jabatan">
                                <Input placeholder="Cari Jabatan..." prefix={<SearchOutlined />} />
                            </Form.Item>
                        </Col>
                        <Col span={4} style={{ display: 'flex', alignItems: 'flex-end', paddingBottom: 24 }}>
                            <Space>
                                <Button onClick={handleReset} icon={<ReloadOutlined />}>Reset</Button>
                                <Button type="primary" htmlType="submit" icon={<SearchOutlined />}>Cari</Button>
                            </Space>
                        </Col>
                    </Row>
                </Form>
            </Card>

            <Card
                title={<span style={{ fontWeight: 'bold', color: '#002766' }}>
                    DAFTAR PETUGAS {viewMode === 'rekursif' ? '(Struktur Hirarki)' : '(Daftar Flat)'}
                </span>}
            >
                {viewMode === 'rekursif' ? (
                    <div>
                        {data.map(petugas => (
                            <PetugasTreeNode key={petugas.id} petugas={petugas} level={0} canEdit={canEdit} canDelete={canDelete} onEdit={handleEdit} onDelete={handleDelete} />
                        ))}
                    </div>
                ) : (
                    <Table
                        columns={visibleColumns}
                        dataSource={data}
                        rowKey="id"
                        loading={loading}
                        pagination={pagination}
                        onChange={handleTableChange}
                    />
                )}
            </Card>

            <Modal
                title="Edit Petugas"
                open={isModalVisible}
                onOk={handleOk}
                onCancel={() => setIsModalVisible(false)}
                okText="Simpan"
                cancelText="Batal"
            >
                <Form form={form} layout="vertical">
                    <Form.Item name="nama_petugas" label="Nama Petugas" rules={[{ required: true }]}>
                        <Input placeholder="Nama Lengkap" />
                    </Form.Item>
                    <Form.Item name="jabatan" label="Jabatan" rules={[{ required: true }]}>
                        <Input placeholder="Contoh: Supervisor" />
                    </Form.Item>
                </Form>
            </Modal>
        </MainLayout>
    );
};

export default PetugasPage;
