import React, { useState, useEffect } from 'react';
import { Table, Button, Modal, Form, Input, InputNumber, message, Typography, Space, Card, Row, Col, Popconfirm } from 'antd';
import { PlusOutlined, EditOutlined, DeleteOutlined, SearchOutlined, ReloadOutlined } from '@ant-design/icons';
import { fetchMasterData, createMasterData, updateMasterData, deleteMasterData } from '../services/api';
import MainLayout from '../components/MainLayout';

import { useAuth } from '../context/AuthContext';

const { Title } = Typography;

const SuratIzinPage = () => {
    const { role } = useAuth();
    const canEdit = ['Admin', 'Staff'].includes(role);
    const canDelete = role === 'Admin';

    const [data, setData] = useState([]);
    const [filteredData, setFilteredData] = useState([]);
    const [loading, setLoading] = useState(false);
    const [isModalVisible, setIsModalVisible] = useState(false);
    const [editingItem, setEditingItem] = useState(null);
    const [form] = Form.useForm();
    const [searchForm] = Form.useForm();

    const loadData = async () => {
        setLoading(true);
        try {
            const result = await fetchMasterData('/surat-izin');
            setData(result || []);
            setFilteredData(result || []);
        } catch (error) {
            message.error('Gagal memuat data surat izin');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadData();
    }, []);

    const handleSearch = (values) => {
        const { id, jenis } = values;
        const filtered = data.filter(item => {
            const matchId = id ? String(item.id).includes(String(id)) : true;
            const matchJenis = jenis ? item.jenis.toLowerCase().includes(jenis.toLowerCase()) : true;
            return matchId && matchJenis;
        });
        setFilteredData(filtered);
    };

    const handleReset = () => {
        searchForm.resetFields();
        setFilteredData(data);
    };

    const handleEdit = (record) => {
        setEditingItem(record);
        form.setFieldsValue(record);
        setIsModalVisible(true);
    };

    const handleDelete = async (id) => {
        try {
            // MODE MOCK: Hapus hanya dari state lokal, tidak menyentuh database
            const newData = data.filter(item => item.id !== id);
            const newFilteredData = filteredData.filter(item => item.id !== id);

            setData(newData);
            setFilteredData(newFilteredData);
            message.success('Surat Izin berhasil dihapus (simulasi - database tidak terpengaruh)');
        } catch (error) {
            message.error('Gagal menghapus surat izin');
        }
    };

    const handleOk = async () => {
        try {
            const values = await form.validateFields();
            if (editingItem) {
                // MODE MOCK: Update hanya di state lokal, tidak menyentuh database
                const newData = data.map(item =>
                    item.id === editingItem.id ? { ...item, ...values } : item
                );
                const newFilteredData = filteredData.map(item =>
                    item.id === editingItem.id ? { ...item, ...values } : item
                );

                setData(newData);
                setFilteredData(newFilteredData);
                message.success('Surat Izin berhasil diperbarui (simulasi - database tidak terpengaruh)');
            }
            setIsModalVisible(false);
        } catch (error) {
            console.error(error);
            message.error('Gagal menyimpan data');
        }
    };

    const columns = [
        { title: 'ID', dataIndex: 'id', key: 'id' },
        { title: 'Jenis Izin', dataIndex: 'jenis', key: 'jenis' },
        {
            title: 'Aksi',
            key: 'aksi',
            render: (_, record) => (
                <Space>
                    {canEdit && (
                        <Button type="link" icon={<EditOutlined />} onClick={() => handleEdit(record)}>
                            Edit
                        </Button>
                    )}
                    {canDelete && (
                        <Popconfirm
                            title="Hapus Data"
                            description="Apakah Anda yakin ingin menghapus surat izin ini?"
                            onConfirm={() => handleDelete(record.id)}
                            okText="Ya"
                            cancelText="Tidak"
                        >
                            <Button type="link" danger icon={<DeleteOutlined />}>Hapus</Button>
                        </Popconfirm>
                    )}
                </Space>
            ),
        },
    ];

    const showAction = canEdit || canDelete;
    const visibleColumns = columns.filter(col => {
        if (col.key === 'aksi' && !showAction) return false;
        return true;
    });

    return (
        <MainLayout>
            <div style={{ marginBottom: 24 }}>
                <Title level={2} style={{ color: '#002766', margin: 0 }}>Kelola Surat Izin</Title>
                <Typography.Text type="secondary">Manajemen lisensi ekspor dan impor</Typography.Text>
            </div>

            <Card title="Pencarian Surat Izin" style={{ marginBottom: 20 }}>
                <Form form={searchForm} layout="vertical" onFinish={handleSearch}>
                    <Row gutter={16}>
                        <Col span={10}>
                            <Form.Item name="id" label="ID Izin">
                                <Input placeholder="Cari ID..." prefix={<SearchOutlined />} />
                            </Form.Item>
                        </Col>
                        <Col span={10}>
                            <Form.Item name="jenis" label="Jenis Izin">
                                <Input placeholder="Cari Jenis (Ekspor, Impor, ...)" prefix={<SearchOutlined />} />
                            </Form.Item>
                        </Col>
                        <Col span={4} style={{ display: 'flex', alignItems: 'flex-end', paddingBottom: 24 }}>
                            <Space>
                                <Button onClick={handleReset} icon={<ReloadOutlined />}>Reset</Button>
                                <Button type="primary" htmlType="submit" icon={<SearchOutlined />}>Cari</Button>
                            </Space>
                        </Col>
                    </Row>
                </Form>
            </Card>

            <Card
                title={<span style={{ fontWeight: 'bold', color: '#002766' }}>DAFTAR SURAT IZIN</span>}
            >
                <Table
                    columns={visibleColumns}
                    dataSource={filteredData}
                    rowKey="id"
                    loading={loading}
                    pagination={{
                        showSizeChanger: true,
                        pageSizeOptions: ['10', '20', '50', '100'],
                        selectProps: { showSearch: false },
                        locale: { items_per_page: '/ page' }
                    }}
                />
            </Card>

            <Modal
                title="Edit Surat Izin"
                open={isModalVisible}
                onOk={handleOk}
                onCancel={() => setIsModalVisible(false)}
                okText="Simpan"
                cancelText="Batal"
            >
                <Form form={form} layout="vertical">
                    <Form.Item name="id" label="ID" rules={[{ required: true }]}>
                        <InputNumber style={{ width: '100%' }} disabled />
                    </Form.Item>
                    <Form.Item name="jenis" label="Jenis Izin" rules={[{ required: true }]}>
                        <Input placeholder="Ekspor/Impor" />
                    </Form.Item>
                </Form>
            </Modal>
        </MainLayout>
    );
};

export default SuratIzinPage;
