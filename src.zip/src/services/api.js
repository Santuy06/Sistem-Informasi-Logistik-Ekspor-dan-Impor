import axios from 'axios';
import { ROLES } from '../utils/constants';

const api = axios.create({
    baseURL: import.meta.env.VITE_API_URL || 'http://localhost:8080/api', // Use Vite env or fallback
});

// Interceptor to add token
api.interceptors.request.use((config) => {
    const token = localStorage.getItem('token');
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
});

// Interceptor to handle 401 Unauthorized (JWT expired or invalid)
api.interceptors.response.use(
    (response) => response,
    (error) => {
        if (error.response?.status === 401) {
            // Token expired or invalid - auto logout
            localStorage.removeItem('token');
            localStorage.removeItem('role');
            localStorage.removeItem('username');

            // Redirect to login if not already there
            if (window.location.pathname !== '/login') {
                window.location.href = '/login';
            }
        }
        return Promise.reject(error);
    }
);

// Real Login to Go Backend
export const login = async (username, password) => {
    try {
        const response = await api.post('/login', { username, password });
        return response.data; // { token, role, username }
    } catch (error) {
        throw new Error(error.response?.data?.error || 'Login failed');
    }
};

// -- Master Data CRUD Helpers --

export const fetchMasterData = async (endpoint) => {
    const response = await api.get(endpoint);
    return response.data;
};

export const createMasterData = async (endpoint, data) => {
    const response = await api.post(endpoint, data);
    return response.data;
};

export const updateMasterData = async (endpoint, id, data) => {
    const response = await api.put(`${endpoint}/${id}`, data);
    return response.data;
};

export const deleteMasterData = async (endpoint, id) => {
    const response = await api.delete(`${endpoint}/${id}`);
    return response.data;
};

// Real Fetch Items from Go Backend
export const fetchItems = async (page = 1, pageSize = 10, filters = {}) => {
    try {
        const params = new URLSearchParams({
            page: page.toString(),
            pageSize: pageSize.toString()
        });

        if (filters.name) params.append('name', filters.name);
        if (filters.type) params.append('type', filters.type);
        if (filters.origin) params.append('origin', filters.origin);
        if (filters.destination) params.append('destination', filters.destination);

        const response = await api.get(`/barang?${params.toString()}`);

        let items = [];
        let total = 0;

        // Handle new response format { data: [...], total: X }
        if (response.data && response.data.data) {
            items = response.data.data;
            total = Number(response.data.total) || 0;
        } else if (Array.isArray(response.data)) {
            items = response.data;
            total = items.length;
        }

        const mappedData = items.map(item => ({
            id: item.id,
            name: item.nama,
            type: item.jenis,
            origin: item.negara_asal,
            destination: item.negara_tujuan,
            price: item.harga,
            tax: item.pajak,
            weight: item.berat_barang,
            surat_izin_id: item.surat_izin_id,
            transportasi_id: item.transportasi_id
        }));

        return {
            data: mappedData,
            total: total,
            page: Number(page),
            pageSize: Number(pageSize)
        };
    } catch (error) {
        console.error("Backend error in fetchItems:", error);
        return { data: [], total: 0, page: 1, pageSize: 10 };
    }
};

// Deprecated: Use fetchBarangStats for charts
export const fetchAllItems = async () => {
    return [];
};

// In-memory cache for statistics (Big Data Optimization)
let statsCache = {
    data: null,
    timestamp: 0
};

// Fetch pre-aggregated statistics for charts (High Performance)
export const fetchBarangStats = async (forceRefresh = false) => {
    const CACHE_TTL = 30000; // 30 seconds
    const now = Date.now();

    if (!forceRefresh && statsCache.data && (now - statsCache.timestamp < CACHE_TTL)) {
        return statsCache.data;
    }

    try {
        const response = await api.get('/barang/stats');
        statsCache = {
            data: response.data,
            timestamp: now
        };
        return response.data;
    } catch (error) {
        console.error("Failed to fetch barang stats", error);
        return {
            destinationStats: [],
            typeStats: [],
            totalValue: 0,
            totalItems: 0
        };
    }
};

// Export clearing cache for when data changes
export const clearStatsCache = () => {
    statsCache.data = null;
    statsCache.timestamp = 0;
};

export const createItem = async (data) => {
    const response = await api.post('/barang', {
        nama: data.name,
        jenis: data.type,
        harga: data.price,
        pajak: data.tax || 0.1,
        berat_barang: data.weight || 1.0,
        surat_izin_id: data.surat_izin_id,
        transportasi_id: data.transportasi_id,
        negara_asal: data.origin,
        negara_tujuan: data.destination
    });
    return response.data;
};

export const updateItem = async (id, data) => {
    const response = await api.put(`/barang/${id}`, {
        nama: data.name,
        jenis: data.type,
        harga: data.price,
        pajak: data.tax,
        berat_barang: data.weight,
        surat_izin_id: data.surat_izin_id,
        transportasi_id: data.transportasi_id,
        negara_asal: data.origin,
        negara_tujuan: data.destination
    });
    return response.data;
};

export const deleteItem = async (id) => {
    const response = await api.delete(`/barang/${id}`);
    return response.data;
};

// Backwards compatibility
export const mockLogin = login;
export const mockFetchItems = fetchItems;

export default api;
