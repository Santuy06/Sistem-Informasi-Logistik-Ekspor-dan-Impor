export const ROLES = {
    ADMIN: 'Admin',
    EDITOR: 'Editor',
    VIEWER: 'Viewer'
};
